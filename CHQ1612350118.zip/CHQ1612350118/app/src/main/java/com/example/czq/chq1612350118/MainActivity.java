package com.example.czq.chq1612350118;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Vibrator;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.baidu.location.BDAbstractLocationListener;
import com.baidu.location.BDLocation;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private ListView listViewp, listViewc;
    List<Province> listp = new ArrayList<Province>();
    List<City> listc = new ArrayList<City>();
    ArrayAdapter<Province> adapterp;
    ArrayAdapter<City> adapterc;
    private EditText editText;
    private Button button;


    SensorManager sm;//感应器
    Vibrator v;//振动器
    Sensor sensor;
    int rate;
    SensorEventListener listener;

    public LocationClient mLocationClient = null;
    private MyLocationListener myListener = new MyLocationListener();

    @SuppressLint("ServiceCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mLocationClient = new LocationClient(getApplicationContext());
        mLocationClient.registerLocationListener( myListener);


        sm = (SensorManager) getSystemService(SENSOR_SERVICE);//初始化
        v = (Vibrator) getSystemService(VIBRATOR_SERVICE);//初始化
        sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);//获取重力感应器
        rate = SensorManager.SENSOR_DELAY_NORMAL;//正常振动频率

        listener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {
                float x = event.values[0];
                float y = event.values[1];
                float z = event.values[2];
                float f = 13;
                int i = (int) (Math.random() * 100) % 5;
                if (Math.abs(x) > f || Math.abs(y) > f || Math.abs(z) > f) {


                    v.vibrate(500);//震动
                    setLocationOption();
                    mLocationClient.start();//开始定位


                }

            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {

            }
        };
        sm.registerListener(listener, sensor, rate);

        listViewp = (ListView) findViewById(R.id.listviewp);
        listViewc = (ListView) findViewById(R.id.listviewc);
        editText = (EditText) findViewById(R.id.edittext);

        initlistp();
        initlistc(listp.get(0).getCode());
        adapterp = new ArrayAdapter<Province>(this, R.layout.listitem_style, listp);
        listViewp.setAdapter(adapterp);
        adapterc = new ArrayAdapter<City>(this, R.layout.listitem_style, listc);
        listViewc.setAdapter(adapterc);

        listViewp.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {


                initlistc(listp.get(pos).getCode());
                adapterc.notifyDataSetChanged();
            }
        });
        listViewc.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                String result = listc.get(pos).getName() + "\r\n" + listc.get(pos).getCode();

                Toast.makeText(MainActivity.this, result, Toast.LENGTH_SHORT).show();
                editText.setText(listc.get(pos).getName());


            }
        });
        button = (Button) findViewById(R.id.button);
            button.setOnClickListener(new  AdapterView.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.putExtra("cityname",editText.getText().toString());
                    intent.setClass(MainActivity.this,other.class);
                    MainActivity.this.startActivity(intent);
                }

        });


    }
    public class MyLocationListener extends BDAbstractLocationListener {

        @Override
        public void onReceiveLocation(BDLocation Location) {
            String addr = Location.getAddrStr();//获取详细地址信息
            String country = Location.getCountry();//获取国家
            String province = Location.getProvince();//获取省份

            String city = Location.getCity();//获取城市
            String district = Location.getDistrict();//获取城市
            String street = Location.getStreet();//获取街道信息

            Toast.makeText(MainActivity.this, "结果为：" + city, Toast.LENGTH_SHORT).show();

            editText.setText(city);

        }
    }



    private void setLocationOption() {
        LocationClientOption option = new LocationClientOption();
        option.setOpenGps(true);//打开GPS
        option.setLocationMode(LocationClientOption.LocationMode.Hight_Accuracy);//设置定位模式
        option.setIsNeedAddress(true);//设置需要的具体地址
        mLocationClient.setLocOption(option);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sm.registerListener(listener, sensor, rate);

    }

    @Override
    protected void onStop() {
        super.onStop();
        v.cancel();
        sm.unregisterListener(listener, sensor);//注销
    }

    @Override
    protected void onDestroy() {
        mLocationClient.stop();
        v.cancel();//取消震动
        sm.unregisterListener(listener, sensor);//注销
        super.onDestroy();
    }


    private void initlistp() {

        try {
            InputStreamReader inputReader = new InputStreamReader(getResources().getAssets().open("province.txt"), "gbk");
            BufferedReader bufReader = new BufferedReader(inputReader);
            String line = "";

            while ((line = bufReader.readLine()) != null) {
                if (!line.trim().equals("")) {
                    Province province = new Province();
                    int index = line.indexOf('=');
                    province.setName(line.substring(index + 1));
                    province.setCode(line.substring(0, index));

                    listp.add(province);
                }
            }
        return;
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    private void initlistc(String provincecode) {
        try {
            InputStreamReader inputReader = new InputStreamReader(getResources().getAssets().open("cities.txt"), "gbk");
            BufferedReader bufReader = new BufferedReader(inputReader);
            String line = "";
            listc.removeAll(listc);
            while ((line = bufReader.readLine()) != null) {
                if (!line.trim().equals("") && line.startsWith(provincecode)) {
                    City ct = new City();
                    int index = line.indexOf('=');
                    ct.setName(line.substring(index + 1));
                    ct.setCode(line.substring(0, index));
                    listc.add(ct);
                }
            }
            return;
        } catch (Exception e) {
            e.printStackTrace();
        }


    }



}










