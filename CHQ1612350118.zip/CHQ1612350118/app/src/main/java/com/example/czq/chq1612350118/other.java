package com.example.czq.chq1612350118;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

public class other extends Activity {
    TextView textView;
    String result;
    String url;
    TextView tvdate,tvcity,tvtempnow,
            tvtemp1,tvweather1,tvwind1,tvindex,
            tvweek2,tvweather2,tvtemp2,tvwind2,
            tvweek3,tvweather3,tvtemp3,tvwind3,
            tvweek4,tvweather4,tvtemp4,tvwind4;

    Root root=null;

    String strpar="";
    AsyncTask<String,Integer,String> mytask;//异步请求

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);
        textView= (TextView) findViewById(R.id.cityname);

        Intent intent=this.getIntent();
        String bundle=intent.getStringExtra("cityname");
        textView.setText(bundle);

        String url="https://www.sojson.com/open/api/weather/json.shtml?city="+bundle;




        tvdate= (TextView) findViewById(R.id.date);
        tvcity= (TextView) findViewById(R.id.cityname);
        tvtempnow= (TextView) findViewById(R.id.tempnow);

        tvtemp1= (TextView) findViewById(R.id.temp1);
        tvweather1= (TextView) findViewById(R.id.weather1);
        tvwind1= (TextView) findViewById(R.id.wind1);
        tvindex= (TextView) findViewById(R.id.zs);

        tvweek2= (TextView) findViewById(R.id.week2);
        tvtemp2= (TextView) findViewById(R.id.temp2);
        tvweather2= (TextView) findViewById(R.id.weather2);
        tvwind2= (TextView) findViewById(R.id.wind2);

        tvweek3= (TextView) findViewById(R.id.week3);
        tvtemp3= (TextView) findViewById(R.id.temp3);
        tvweather3= (TextView) findViewById(R.id.weather3);
        tvwind3= (TextView) findViewById(R.id.wind3);

        tvweek4= (TextView) findViewById(R.id.week4);
        tvtemp4= (TextView) findViewById(R.id.temp4);
        tvweather4= (TextView) findViewById(R.id.weather4);
        tvwind4= (TextView) findViewById(R.id.wind4);



        mytask=new AsyncTask<String, Integer, String>() {
            @Override
            protected String doInBackground(String... strings) {
                try {
                    strpar=util.getJsonString(strings[0]);
                    return strpar;
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                root=util.resolveRoot(strpar);
                if (root.getStatus()==200){
                    Data data=root.getData();
                    Yesterday yesterday=data.getYesterday();
                    List<Forecast>forecast=data.getForecast();
                    Forecast nowAdays = forecast.get(0);
                    Forecast tomorrow = forecast.get(1);
                    Forecast acquired = forecast.get(2);
                    Forecast lastDay = forecast.get(3);

                    tvcity.setText(root.getCity());
                    tvdate.setText(nowAdays.getDate());
                    tvtempnow.setText(data.getWendu()+"℃");
                    tvweather1.setText(nowAdays.getType());
                    tvtemp1.setText(nowAdays.getLow().substring(2)
                            +"～"+nowAdays.getHigh().substring(2));
                    tvwind1.setText(nowAdays.getFx());

                    tvindex.setText(nowAdays.getNotice());

                    tvweek2.setText(tomorrow.getDate());
                    tvweek3.setText(acquired.getDate());
                    tvweek4.setText(lastDay.getDate());

                    tvweather2.setText(tomorrow.getType());
                    tvweather3.setText(acquired.getType());
                    tvweather4.setText(lastDay.getType());

                    tvtemp2.setText(tomorrow.getLow().substring(2)
                            +"～"+tomorrow.getHigh().substring(2));
                    tvtemp3.setText(acquired.getLow().substring(2)
                            +"～"+acquired.getHigh().substring(2));
                    tvtemp4.setText(lastDay.getLow().substring(2)
                            +"～"+lastDay.getHigh().substring(2));

                    tvwind2.setText(tomorrow.getFx());
                    tvwind3.setText(acquired.getFx());
                    tvwind4.setText(lastDay.getFx());
                }else{
                    tvdate.setText(root.getMessage());
                }
            }
        };

        mytask.execute(url);

        tvindex.setSelected(true);

    }
}
