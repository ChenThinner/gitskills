package com.example.czq.chq1612350118;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;

//import com.example.czq.chq1612350118.other.Root;


/**
 * Created by CZQ on 2018/5/12.
 */
public class util {
    public static String getJsonString(String urlPath) throws Exception{
        URL url =new URL(urlPath);
        HttpURLConnection connection =
                (HttpURLConnection) url.openConnection();

        connection.connect();
        InputStream inputStream = connection.getInputStream();
        Reader reader = new InputStreamReader(inputStream,"UTF-8");
        BufferedReader bufferedReader = new BufferedReader(reader);
        String str = null;
        StringBuffer sb = new StringBuffer();
        while ((str = bufferedReader.readLine())!=null){
            sb.append(str);
        }
        reader.close();
        connection.disconnect();
        return  sb.toString();
    }

    public static Root resolveRoot(String strPar){


            Gson gson = new Gson();
            Root root = gson.fromJson(strPar, Root.class);
            return root;

      /*    JSONObject  rootOfJson = JSONObject.fromObjecct(strPar);
            if (rootOfJson.getInt("status")!=200){return  null;}
            Map<String,Class<Forecast>>map=new HashMap<String ,Class<Forecast>>();
            map.put("forecast", Forecast.class);

            DocumentsContract.Root root = (DocumentsContract.Root) JSONObject.toBean(rootOfJson, DocumentsContract.Root.class, map);
            return root;*/
          }


}