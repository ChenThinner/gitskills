package com.example.czq.chq1612350118;

public class Lifestyle
{
    private String type;

    private String brf;

    private String txt;

    public void setType(String type){
        this.type = type;
    }
    public String getType(){
        return this.type;
    }
    public void setBrf(String brf){
        this.brf = brf;
    }
    public String getBrf(){
        return this.brf;
    }
    public void setTxt(String txt){
        this.txt = txt;
    }
    public String getTxt(){
        return this.txt;
    }
}
